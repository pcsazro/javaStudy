package com.mega.mvc05.car;


public class LGWindow implements Window { 
	//추상적인(abstract) 메소드를 가지고 있으므로 모두 구현 되어야 한다.
	
	@Override
	public void open() {
		System.out.println("LG 창문이 열리다.");
	}

	@Override
	public void close() {
		System.out.println("LG 창문이 닫히다.");
	}

}
