package com.mega.mvc05.car;

import javax.swing.JOptionPane;

public class CarMain2 {
	
	public static Window w;
	
	public static void main(String[] args) {
		
		String name = JOptionPane.showInputDialog("kcc, lg 중 선택");
		
		Factory factory = new Factory();
		w = (Window)factory.getBean(name);
		// name인 String이 factory.getBean에서 object로 반환되므로
		// (Window)는 다운캐스팅
		
		Car a = new AppleCar(w);
		a.run();
		a.stop();
		
		Car b = new BananaCar(w);
		b.run();
		b.stop();
		
	}

}
