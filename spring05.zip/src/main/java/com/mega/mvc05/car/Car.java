package com.mega.mvc05.car;

public interface Car {
	public abstract void run();
	public abstract void stop();
}
