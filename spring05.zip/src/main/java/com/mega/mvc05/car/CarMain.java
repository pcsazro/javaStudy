package com.mega.mvc05.car;

public class CarMain {
	
	public static void main(String[] args) {
		KCCWindow w = new KCCWindow();
		Car b = new BananaCar(w);
		b.run();
		b.stop();
		
		
	}

}
