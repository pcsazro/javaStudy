package com.mega.mvc05.car;

public class BananaCar implements Car {
	
	Window w;

	public BananaCar(Window w) {
//		super();  //default
		this.w = w;
	}

	@Override
	public void run() {
		System.out.println("BananaCar 달리다.");
//		w = new LGWindow();
		w.open(); // w는 주소값
		// Car는 Window에 의존적(dependency)이다.
		// 코드상으로는 해당 객체에 주소값만 있으면 됨.
		// 필요할 때 창문 클래스를 복사해ㅅ 객체를 사용함.
	}

	@Override
	public void stop() {
		System.out.println("BananaCar 멈추다.");
		w.close();
	}

}
