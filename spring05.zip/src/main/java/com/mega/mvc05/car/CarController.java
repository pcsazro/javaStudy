package com.mega.mvc05.car;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller // 1.controller 등록, 2.controller 상속
public class CarController {
	
	@Autowired 
	@Qualifier("a") // 주입할 객체(instance)가 2개 이상일 때 ("a"는 Bean 이름)
	Car cara; // AppleCar, BananaCar 둘 다 쓸 경우
//	BananaCar car; // BananaCar만 사용할 경우
	// 외부 파일에서 만든 주소를 car 변수에 spring이 찾아서 넣어준다.
	// 의존성(dependency)을 맺어주는 건 주소만 있으면 된다.
	// Car 상속이나, 구현된 객체의 생성된 주소를 찾아서 주입.
	
	@Autowired
	@Qualifier("b")
	Car carb;
	
	@RequestMapping("car.do")
	public void run() {
		cara.run();
		carb.run();
	}
}
