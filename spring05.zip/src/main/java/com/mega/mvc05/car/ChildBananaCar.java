package com.mega.mvc05.car;

public class ChildBananaCar extends BananaCar {
	public void up() {
		System.out.println("속도를 Up시키다.");
	}
}
