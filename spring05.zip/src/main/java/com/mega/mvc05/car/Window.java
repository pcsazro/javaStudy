package com.mega.mvc05.car;

public interface Window {
	// 인터페이스에는 일반변수를 넣지 않는다.
	// 곡 있어야 하는 기능 중심으로 규격을 정의 하는 문서 역할
	public abstract void open();
	public abstract void close();
}
