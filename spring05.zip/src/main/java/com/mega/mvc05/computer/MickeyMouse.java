package com.mega.mvc05.computer;

public class MickeyMouse implements Mouse {

	@Override
	public void click() {
		System.out.println("MickeyMouse를 클릭합니다.");
	}

}
