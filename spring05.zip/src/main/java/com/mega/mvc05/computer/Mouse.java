package com.mega.mvc05.computer;

public interface Mouse {
	public abstract void click();
}
