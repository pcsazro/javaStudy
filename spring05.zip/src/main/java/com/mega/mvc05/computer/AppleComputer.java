package com.mega.mvc05.computer;

public class AppleComputer implements Computer {
	
	Mouse m;

	@Override
	public void on() {
		System.out.println("AppleComputer를 켭니다.");
		m = new MickeyMouse();
		m.click();
	}

	@Override
	public void off() {
		System.out.println("AppleComputer를 끕니다.");
	}

}
