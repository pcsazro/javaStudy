package com.mega.mvc05.computer;

public class BananaComputer implements Computer {
	
	MiniMouse mm;

	@Override
	public void on() {
		System.out.println("BananaComputer를 켭니다.");
		mm.click();
	}

	@Override
	public void off() {
		System.out.println("BananaComputer를 끕니다.");
	}

}
