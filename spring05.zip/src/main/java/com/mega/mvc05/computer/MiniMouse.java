package com.mega.mvc05.computer;

public class MiniMouse implements Mouse {

	@Override
	public void click() {
		System.out.println("Minimouse를 클릭합니다.");
	}

}
