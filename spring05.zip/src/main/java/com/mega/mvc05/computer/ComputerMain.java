package com.mega.mvc05.computer;

public class ComputerMain {

	public static void main(String[] args) {
		Computer c = new AppleComputer();
		c.on();
		c.off();
		
		Computer d = new BananaComputer();
		d.on();
		d.off();
	}

}
