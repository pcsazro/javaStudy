package com.mega.mvc05.computer;

public interface Computer {
	public abstract void on();
	public abstract void off();
}
