package com.mega.mvc05;

import java.util.ArrayList;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

// @service: 처리와 관련된 클래스
//@Repository // component와 같은 기능이나 DAO에서만 사용가능) 
@Component("memberDAO") // 같은 것이 있어 구별이 필요한 경우 (예제는 default로 지워도 된다.)
public class MemberDAO {
	
	public ArrayList<String> select(String find) {
		ArrayList<String> list = new ArrayList<String>();
		if (find.equals("자동차")) {
			list.add("Benz");
			list.add("BMW");
			list.add("fox");
		} else {
			list.add("boing747");
			list.add("congcod");
		}
		return list;
	}
	
	public void insert(MemberDTO dto) {
		System.out.println("dao dto"+dto);
	}
	
	public int login(MemberDTO dto) {
		int result = 0;
		String id = "root";
		String pw = "1234";
		
		if (id.equals(dto.getId()) && pw.equals(dto.getPw())) {
			result = 1;
		}
		
		return result;
	}
}
