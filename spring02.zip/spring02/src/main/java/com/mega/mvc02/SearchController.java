package com.mega.mvc02;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

// POJO

@Controller // Annotation(표시)
public class SearchController {

	@RequestMapping("find.mega")
	public void find(String search) { 
		// 메소드 이름(find)은 상관없고 맵핑된 주소(find.mega)가 중요
		// 받아주는 변수 이름을 보내는 "name"과 동일하게 하면 값을 받아온다. 
		System.out.println("find()함수 호출됨");
		System.out.println("검색할 데이터는 "+search);
	}
}
