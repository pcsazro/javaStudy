package com.mega.mvc02;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sun.org.glassfish.gmbal.ParameterNames;

@Controller
public class LoginController {
	
	@RequestMapping("check.do")
	public void check(String id, String pw, @RequestParam("etc") String etc2) {
		// 변수 이름을 바꿔야 할 경우 @Requestparam을 이용한다.
		System.out.println("입력받은 아 이 디: "+id);
		System.out.println("입력받은 비밀번호: "+pw);
		// 로그인 처리 (DAO 사용)
	}
}
