package com.mega.mvc02;

public class BbsDTO {
	private String no;
	private String title;
	private String contents;
	private String writer;
	
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	
	@Override
	public String toString() {
		return "BbsDTO [no=" + no + ", title=" + title + ", contents=" + contents + ", writer=" + writer + "]";
	}
}
