package com.mega.mvc04;

import java.util.ArrayList;

public class MemberDAO {
	
	public ArrayList<String> select(String find) {
		ArrayList<String> list = new ArrayList<String>();
		if (find.equals("�ڵ���")) {
			list.add("����");
			list.add("BMW");
			list.add("�����ٰ�");
		} else {
			list.add("����747");
			list.add("���ڵ�");
		}
		return list;
	}
	
	public void insert(MemberDTO dto) {
		System.out.println("dao���� ���� dto����\n"+dto);
	}
	
	public int login(MemberDTO dto) {
		int result = 0;
		String id = "root";
		String pw = "1234";
		
		if (id.equals(dto.getId()) && pw.equals(dto.getPw())) {
			result = 1;
		}
		
		return result;
	}
}
