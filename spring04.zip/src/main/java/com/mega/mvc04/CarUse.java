package com.mega.mvc04;

public class CarUse {

	public static void main(String[] args) {
		System.out.println("�ڵ� �����");
		AppleCar apple = new AppleCar();
		apple.run();
		apple.speedUp();
		
	}

}
