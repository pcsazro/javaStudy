package com.mega.mvc04;

import java.util.ArrayList;

public class WeatherDAO {
	
	public ArrayList<WeatherDTO> select(String date) {
		ArrayList<WeatherDTO> list = new ArrayList<WeatherDTO>();
		System.out.println(list);
		WeatherDTO dto = new WeatherDTO();
				if (date.equals("1")) {
					dto.setDate(date);
					dto.setWeather("����");
					dto.setTemperature("18'C");
					dto.setMicrodust("����");
					dto.setRainfall("0mm");
				} else if(date.equals("2")){
					dto.setDate(date);
					dto.setWeather("��");
					dto.setTemperature("12'C");
					dto.setMicrodust("����");
					dto.setRainfall("100mm");
				}
				list.add(dto);
				System.out.println(list);
		return list;
		
	}
}
