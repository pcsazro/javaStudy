package com.mega.mvc04;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WeatherController {
	
	@Autowired
	WeatherDAO dao;
	
	@RequestMapping("weather.do")
	public String weather(String date, Model model) {
		ArrayList<WeatherDTO> list = dao.select(date);
		System.out.println(list);
//		model.addAttribute("lista", lista);
		model.addAttribute("date", date);
		model.addAttribute("weather", list.get(0).getWeather());
		model.addAttribute("temp", list.get(0).getTemperature());
		model.addAttribute("dust", list.get(0).getMicrodust());
		model.addAttribute("rain", list.get(0).getRainfall());
		System.out.println(list.size());
		
		String w = "wea";
		return w;
	}
}
