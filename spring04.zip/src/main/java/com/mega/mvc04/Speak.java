package com.mega.mvc04;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class Speak implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		System.out.println("mvc04 context ����.");
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		System.out.println("mvc04 context ����.");
	}

}
