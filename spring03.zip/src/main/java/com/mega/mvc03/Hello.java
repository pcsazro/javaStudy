package com.mega.mvc03;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Hello extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init() 호출됨.");
		String driver = config.getInitParameter("driver");
		if(driver.equals("com.mysql.jdbc.Driver")) {
			System.out.println("mySQL서버에 연결");
		} else {
			System.out.println("오라클 서버에 연결");
		}
	}
	
	public Hello() {
		System.out.println("기본 생성자 호출됨.");
	}
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Get요청 들어옴.");
		PrintWriter out = response.getWriter();
		out.println("Get received!");
		String id = request.getParameter("id");
		out.println("your name is "+id); // root
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Post요청 들어옴.");
		PrintWriter out = response.getWriter();
		out.println("Post received!");
		String id = request.getParameter("id");
		out.println("your name is "+id); // admin
	}

}
