package mainprogram;

public class UpDTO {

	
		
		int no; // 넘버링
		String category; // 분류
		String model; // 상품명
		String brand; // 브랜드명
		String size; // 옷사이즈
		String length; // 전체기장
		String width; // 어깨 너비
		String chest; // 가슴둘레
		String armlength; // 팔 길이
		String armcircle; // 팔 둘레
		public int getNo() {
			return no;
		}
		public void setNo(int no) {
			this.no = no;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public String getModel() {
			return model;
		}
		public void setModel(String model) {
			this.model = model;
		}
		public String getBrand() {
			return brand;
		}
		public void setBrand(String brand) {
			this.brand = brand;
		}
		public String getSize() {
			return size;
		}
		public void setSize(String size) {
			this.size = size;
		}
		public String getLength() {
			return length;
		}
		public void setLength(String length) {
			this.length = length;
		}
		public String getWidth() {
			return width;
		}
		public void setWidth(String width) {
			this.width = width;
		}
		public String getChest() {
			return chest;
		}
		public void setChest(String chest) {
			this.chest = chest;
		}
		public String getArmlength() {
			return armlength;
		}
		public void setArmlength(String armlength) {
			this.armlength = armlength;
		}
		public String getArmcircle() {
			return armcircle;
		}
		public void setArmcircle(String armcircle) {
			this.armcircle = armcircle;
		}

	

}
