package bean;

public class game_detailDTO {

	String gmkey;
	String home_team;
	String home_inning1;
	String home_inning2;
	String home_inning3;
	String home_inning4;
	String home_inning5;
	String home_inning6;
	String home_inning7;
	String home_inning8;
	String home_inning9;
	String home_inning10;
	String home_inning11;
	String home_inning12;
	String visit_team;
	String visit_inning1;
	String visit_inning2;
	String visit_inning3;
	String visit_inning4;
	String visit_inning5;
	String visit_inning6;
	String visit_inning7;
	String visit_inning8;
	String visit_inning9;
	String visit_inning10;
	String visit_inning11;
	String visit_inning12;
	
	public String getGmkey() {
		return gmkey;
	}
	public void setGmkey(String gmkey) {
		this.gmkey = gmkey;
	}
	public String getHome_team() {
		return home_team;
	}
	public void setHome_team(String home_team) {
		this.home_team = home_team;
	}
	public String getHome_inning1() {
		return home_inning1;
	}
	public void setHome_inning1(String home_inning1) {
		this.home_inning1 = home_inning1;
	}
	public String getHome_inning2() {
		return home_inning2;
	}
	public void setHome_inning2(String home_inning2) {
		this.home_inning2 = home_inning2;
	}
	public String getHome_inning3() {
		return home_inning3;
	}
	public void setHome_inning3(String home_inning3) {
		this.home_inning3 = home_inning3;
	}
	public String getHome_inning4() {
		return home_inning4;
	}
	public void setHome_inning4(String home_inning4) {
		this.home_inning4 = home_inning4;
	}
	public String getHome_inning5() {
		return home_inning5;
	}
	public void setHome_inning5(String home_inning5) {
		this.home_inning5 = home_inning5;
	}
	public String getHome_inning6() {
		return home_inning6;
	}
	public void setHome_inning6(String home_inning6) {
		this.home_inning6 = home_inning6;
	}
	public String getHome_inning7() {
		return home_inning7;
	}
	public void setHome_inning7(String home_inning7) {
		this.home_inning7 = home_inning7;
	}
	public String getHome_inning8() {
		return home_inning8;
	}
	public void setHome_inning8(String home_inning8) {
		this.home_inning8 = home_inning8;
	}
	public String getHome_inning9() {
		return home_inning9;
	}
	public void setHome_inning9(String home_inning9) {
		this.home_inning9 = home_inning9;
	}
	public String getHome_inning10() {
		return home_inning10;
	}
	public void setHome_inning10(String home_inning10) {
		this.home_inning10 = home_inning10;
	}
	public String getHome_inning11() {
		return home_inning11;
	}
	public void setHome_inning11(String home_inning11) {
		this.home_inning11 = home_inning11;
	}
	public String getHome_inning12() {
		return home_inning12;
	}
	public void setHome_inning12(String home_inning12) {
		this.home_inning12 = home_inning12;
	}
	public String getVisit_team() {
		return visit_team;
	}
	public void setVisit_team(String visit_team) {
		this.visit_team = visit_team;
	}
	public String getVisit_inning1() {
		return visit_inning1;
	}
	public void setVisit_inning1(String visit_inning1) {
		this.visit_inning1 = visit_inning1;
	}
	public String getVisit_inning2() {
		return visit_inning2;
	}
	public void setVisit_inning2(String visit_inning2) {
		this.visit_inning2 = visit_inning2;
	}
	public String getVisit_inning3() {
		return visit_inning3;
	}
	public void setVisit_inning3(String visit_inning3) {
		this.visit_inning3 = visit_inning3;
	}
	public String getVisit_inning4() {
		return visit_inning4;
	}
	public void setVisit_inning4(String visit_inning4) {
		this.visit_inning4 = visit_inning4;
	}
	public String getVisit_inning5() {
		return visit_inning5;
	}
	public void setVisit_inning5(String visit_inning5) {
		this.visit_inning5 = visit_inning5;
	}
	public String getVisit_inning6() {
		return visit_inning6;
	}
	public void setVisit_inning6(String visit_inning6) {
		this.visit_inning6 = visit_inning6;
	}
	public String getVisit_inning7() {
		return visit_inning7;
	}
	public void setVisit_inning7(String visit_inning7) {
		this.visit_inning7 = visit_inning7;
	}
	public String getVisit_inning8() {
		return visit_inning8;
	}
	public void setVisit_inning8(String visit_inning8) {
		this.visit_inning8 = visit_inning8;
	}
	public String getVisit_inning9() {
		return visit_inning9;
	}
	public void setVisit_inning9(String visit_inning9) {
		this.visit_inning9 = visit_inning9;
	}
	public String getVisit_inning10() {
		return visit_inning10;
	}
	public void setVisit_inning10(String visit_inning10) {
		this.visit_inning10 = visit_inning10;
	}
	public String getVisit_inning11() {
		return visit_inning11;
	}
	public void setVisit_inning11(String visit_inning11) {
		this.visit_inning11 = visit_inning11;
	}
	public String getVisit_inning12() {
		return visit_inning12;
	}
	public void setVisit_inning12(String visit_inning12) {
		this.visit_inning12 = visit_inning12;
	}
	
	@Override
	public String toString() {
		return "game_detailDTO [gmkey=" + gmkey + ", home_team=" + home_team + ", home_inning1=" + home_inning1
				+ ", home_inning2=" + home_inning2 + ", home_inning3=" + home_inning3 + ", home_inning4=" + home_inning4
				+ ", home_inning5=" + home_inning5 + ", home_inning6=" + home_inning6 + ", home_inning7=" + home_inning7
				+ ", home_inning8=" + home_inning8 + ", home_inning9=" + home_inning9 + ", home_inning10="
				+ home_inning10 + ", home_inning11=" + home_inning11 + ", home_inning12=" + home_inning12
				+ ", visit_team=" + visit_team + ", visit_inning1=" + visit_inning1 + ", visit_inning2=" + visit_inning2
				+ ", visit_inning3=" + visit_inning3 + ", visit_inning4=" + visit_inning4 + ", visit_inning5="
				+ visit_inning5 + ", visit_inning6=" + visit_inning6 + ", visit_inning7=" + visit_inning7
				+ ", visit_inning8=" + visit_inning8 + ", visit_inning9=" + visit_inning9 + ", visit_inning10="
				+ visit_inning10 + ", visit_inning11=" + visit_inning11 + ", visit_inning12=" + visit_inning12 + "]";
	}
	
}
