package bean;

public class gamekeyDTO {
	String gmkey;

	public String getGmkey() {
		return gmkey;
	}

	public void setGmkey(String gmkey) {
		this.gmkey = gmkey;
	}

	@Override
	public String toString() {
		return gmkey;
	}

	public Object setGmkey(gamekeyDTO gamekeyDTO) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
