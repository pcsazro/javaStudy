package com.mega.mvc07;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class replydao {
	
	@Autowired
	SqlSessionTemplate my;
	
	public List<replyDTO> all(replyDTO dto) {
		List<replyDTO> list = my.selectList("reply.all", dto);
		return list;
	}
	
	public void add(replyDTO dto) {
		my.insert("reply.add", dto);
	}
	
}
