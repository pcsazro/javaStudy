package com.mega.mvc07;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BbsController {

	@Autowired
	BbsDAO dao;
	
	@Autowired
	replydao rdao;
	
	@RequestMapping("bbs_list.do")
	public String list(Model model) {
		List<BbsDTO> list = dao.list();
//		System.out.println(list);
		model.addAttribute("blist", list);
		String id = "bbs";
		return id;
	}
	
	@RequestMapping("tselect.do")
	public String title(BbsDTO bbsDTO, replyDTO replyDTO, Model model, HttpSession session) {
		session.setAttribute("writer", "aaa");
		BbsDTO dto = dao.select(bbsDTO);
		model.addAttribute("tdto", dto);
		
		replyDTO.setBbsNum(bbsDTO.getNo());
//		System.out.println(bbsDTO);
		List<replyDTO> rlist = rdao.all(replyDTO);
		model.addAttribute("rlist", rlist);
		
		String id = "title";
		return id;
	}
	
}
