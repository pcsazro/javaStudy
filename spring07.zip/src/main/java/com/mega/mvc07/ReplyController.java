package com.mega.mvc07;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ReplyController {
	
	@Autowired
	replydao dao;
	
	@RequestMapping("all.do")
	public void all(replyDTO replyDTO, Model model) {
		List<replyDTO> rlist = dao.all(replyDTO);
		model.addAttribute("rlist", rlist);
	}
	
	@RequestMapping("add.do")
	public void add(replyDTO replyDTO) {
		dao.add(replyDTO);
	}
}
