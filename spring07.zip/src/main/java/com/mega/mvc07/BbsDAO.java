package com.mega.mvc07;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BbsDAO {
	
	@Autowired
	SqlSessionTemplate my;
	
	public List<BbsDTO> list() {
		List<BbsDTO> list = my.selectList("bbs.blist");
		return list;
	}
	
	public BbsDTO select(BbsDTO dto) {
		BbsDTO dto2 = my.selectOne("bbs.tselect", dto);
		return dto2;
	}
}
